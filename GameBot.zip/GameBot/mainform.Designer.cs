﻿namespace GameBot
{
    partial class mainform
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("asdfasfdasfasfd");
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("asdfasfdasfasfd");
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("asdfasfdasfasfd");
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.chkPowerBallPlus = new System.Windows.Forms.CheckBox();
            this.chkLottoPlus2 = new System.Windows.Forms.CheckBox();
            this.chkLottoPlus1 = new System.Windows.Forms.CheckBox();
            this.btnDeletedSelectedReceiptsNL = new System.Windows.Forms.Button();
            this.listViewNL = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.btnRemoveSavedTicketsNL = new System.Windows.Forms.Button();
            this.btnLoadGameFileNL = new System.Windows.Forms.Button();
            this.chkPayWalletNL = new System.Windows.Forms.CheckBox();
            this.cmbColumnNL = new System.Windows.Forms.ComboBox();
            this.cmbGameNL = new System.Windows.Forms.ComboBox();
            this.txtPinNL = new System.Windows.Forms.TextBox();
            this.txtMobileNoNL = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblMobileNo = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cmbGameHB = new System.Windows.Forms.ComboBox();
            this.listViewHB = new System.Windows.Forms.ListView();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.btnLoadGameFileHB = new System.Windows.Forms.Button();
            this.btnDeleteSelectedReceiptsHB = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBetAmountHB = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtUsernameHB = new System.Windows.Forms.TextBox();
            this.txtPasswordHB = new System.Windows.Forms.TextBox();
            this.cmbColumnHB = new System.Windows.Forms.ComboBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnStartWager = new System.Windows.Forms.Button();
            this.cmbGameWebsiteWager = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.listView3 = new System.Windows.Forms.ListView();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.btnRemoveTickets = new System.Windows.Forms.Button();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 3;
            this.tabControl1.Size = new System.Drawing.Size(310, 541);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.chkPowerBallPlus);
            this.tabPage1.Controls.Add(this.chkLottoPlus2);
            this.tabPage1.Controls.Add(this.chkLottoPlus1);
            this.tabPage1.Controls.Add(this.btnDeletedSelectedReceiptsNL);
            this.tabPage1.Controls.Add(this.listViewNL);
            this.tabPage1.Controls.Add(this.btnRemoveSavedTicketsNL);
            this.tabPage1.Controls.Add(this.btnLoadGameFileNL);
            this.tabPage1.Controls.Add(this.chkPayWalletNL);
            this.tabPage1.Controls.Add(this.cmbColumnNL);
            this.tabPage1.Controls.Add(this.cmbGameNL);
            this.tabPage1.Controls.Add(this.txtPinNL);
            this.tabPage1.Controls.Add(this.txtMobileNoNL);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.lblMobileNo);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(302, 513);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "NL Games";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // chkPowerBallPlus
            // 
            this.chkPowerBallPlus.AutoSize = true;
            this.chkPowerBallPlus.Location = new System.Drawing.Point(14, 195);
            this.chkPowerBallPlus.Name = "chkPowerBallPlus";
            this.chkPowerBallPlus.Size = new System.Drawing.Size(128, 19);
            this.chkPowerBallPlus.TabIndex = 7;
            this.chkPowerBallPlus.Text = "Add PowerBall Plus";
            this.chkPowerBallPlus.UseVisualStyleBackColor = true;
            // 
            // chkLottoPlus2
            // 
            this.chkLottoPlus2.AutoSize = true;
            this.chkLottoPlus2.Location = new System.Drawing.Point(173, 171);
            this.chkLottoPlus2.Name = "chkLottoPlus2";
            this.chkLottoPlus2.Size = new System.Drawing.Size(110, 19);
            this.chkLottoPlus2.TabIndex = 7;
            this.chkLottoPlus2.Text = "Add Lotto Plus2";
            this.chkLottoPlus2.UseVisualStyleBackColor = true;
            // 
            // chkLottoPlus1
            // 
            this.chkLottoPlus1.AutoSize = true;
            this.chkLottoPlus1.Location = new System.Drawing.Point(14, 171);
            this.chkLottoPlus1.Name = "chkLottoPlus1";
            this.chkLottoPlus1.Size = new System.Drawing.Size(110, 19);
            this.chkLottoPlus1.TabIndex = 7;
            this.chkLottoPlus1.Text = "Add Lotto Plus1";
            this.chkLottoPlus1.UseVisualStyleBackColor = true;
            // 
            // btnDeletedSelectedReceiptsNL
            // 
            this.btnDeletedSelectedReceiptsNL.Location = new System.Drawing.Point(14, 456);
            this.btnDeletedSelectedReceiptsNL.Name = "btnDeletedSelectedReceiptsNL";
            this.btnDeletedSelectedReceiptsNL.Size = new System.Drawing.Size(269, 23);
            this.btnDeletedSelectedReceiptsNL.TabIndex = 5;
            this.btnDeletedSelectedReceiptsNL.Text = "Delete selected payment receipts";
            this.btnDeletedSelectedReceiptsNL.UseVisualStyleBackColor = true;
            this.btnDeletedSelectedReceiptsNL.Click += new System.EventHandler(this.btnDeletedSelectedReceiptsNL_Click);
            // 
            // listViewNL
            // 
            this.listViewNL.CheckBoxes = true;
            this.listViewNL.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.listViewNL.GridLines = true;
            this.listViewNL.HideSelection = false;
            listViewItem1.StateImageIndex = 0;
            this.listViewNL.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
            this.listViewNL.LabelWrap = false;
            this.listViewNL.Location = new System.Drawing.Point(14, 278);
            this.listViewNL.Name = "listViewNL";
            this.listViewNL.Size = new System.Drawing.Size(269, 161);
            this.listViewNL.TabIndex = 6;
            this.listViewNL.UseCompatibleStateImageBehavior = false;
            this.listViewNL.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Payment Receipts";
            this.columnHeader1.Width = 250;
            // 
            // btnRemoveSavedTicketsNL
            // 
            this.btnRemoveSavedTicketsNL.Location = new System.Drawing.Point(14, 249);
            this.btnRemoveSavedTicketsNL.Name = "btnRemoveSavedTicketsNL";
            this.btnRemoveSavedTicketsNL.Size = new System.Drawing.Size(269, 23);
            this.btnRemoveSavedTicketsNL.TabIndex = 5;
            this.btnRemoveSavedTicketsNL.Text = "Remove all my current saved Tickets";
            this.btnRemoveSavedTicketsNL.UseVisualStyleBackColor = true;
            this.btnRemoveSavedTicketsNL.Click += new System.EventHandler(this.btnRemoveSavedTicketsNL_Click);
            // 
            // btnLoadGameFileNL
            // 
            this.btnLoadGameFileNL.Location = new System.Drawing.Point(14, 220);
            this.btnLoadGameFileNL.Name = "btnLoadGameFileNL";
            this.btnLoadGameFileNL.Size = new System.Drawing.Size(269, 23);
            this.btnLoadGameFileNL.TabIndex = 5;
            this.btnLoadGameFileNL.Text = "Browse to load game file";
            this.btnLoadGameFileNL.UseVisualStyleBackColor = true;
            this.btnLoadGameFileNL.Click += new System.EventHandler(this.btnLoadGameFileNL_Click);
            // 
            // chkPayWalletNL
            // 
            this.chkPayWalletNL.AutoSize = true;
            this.chkPayWalletNL.Location = new System.Drawing.Point(14, 146);
            this.chkPayWalletNL.Name = "chkPayWalletNL";
            this.chkPayWalletNL.Size = new System.Drawing.Size(259, 19);
            this.chkPayWalletNL.TabIndex = 4;
            this.chkPayWalletNL.Text = "Pay from My Wallet if funds will be available";
            this.chkPayWalletNL.UseVisualStyleBackColor = true;
            // 
            // cmbColumnNL
            // 
            this.cmbColumnNL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbColumnNL.FormattingEnabled = true;
            this.cmbColumnNL.Location = new System.Drawing.Point(89, 103);
            this.cmbColumnNL.Name = "cmbColumnNL";
            this.cmbColumnNL.Size = new System.Drawing.Size(194, 23);
            this.cmbColumnNL.TabIndex = 3;
            // 
            // cmbGameNL
            // 
            this.cmbGameNL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGameNL.FormattingEnabled = true;
            this.cmbGameNL.Location = new System.Drawing.Point(89, 74);
            this.cmbGameNL.Name = "cmbGameNL";
            this.cmbGameNL.Size = new System.Drawing.Size(194, 23);
            this.cmbGameNL.TabIndex = 3;
            this.cmbGameNL.SelectedIndexChanged += new System.EventHandler(this.cmbGameNL_SelectedIndexChanged);
            // 
            // txtPinNL
            // 
            this.txtPinNL.Location = new System.Drawing.Point(89, 43);
            this.txtPinNL.Name = "txtPinNL";
            this.txtPinNL.Size = new System.Drawing.Size(194, 23);
            this.txtPinNL.TabIndex = 2;
            this.txtPinNL.UseSystemPasswordChar = true;
            // 
            // txtMobileNoNL
            // 
            this.txtMobileNoNL.Location = new System.Drawing.Point(89, 15);
            this.txtMobileNoNL.Name = "txtMobileNoNL";
            this.txtMobileNoNL.Size = new System.Drawing.Size(194, 23);
            this.txtMobileNoNL.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "Column";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Game:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Pin:";
            // 
            // lblMobileNo
            // 
            this.lblMobileNo.AutoSize = true;
            this.lblMobileNo.Location = new System.Drawing.Point(14, 18);
            this.lblMobileNo.Name = "lblMobileNo";
            this.lblMobileNo.Size = new System.Drawing.Size(69, 15);
            this.lblMobileNo.TabIndex = 1;
            this.lblMobileNo.Text = "Mobile No.:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.cmbGameHB);
            this.tabPage2.Controls.Add(this.listViewHB);
            this.tabPage2.Controls.Add(this.btnLoadGameFileHB);
            this.tabPage2.Controls.Add(this.btnDeleteSelectedReceiptsHB);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtBetAmountHB);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.txtUsernameHB);
            this.tabPage2.Controls.Add(this.txtPasswordHB);
            this.tabPage2.Controls.Add(this.cmbColumnHB);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(302, 513);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "HB Games";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // cmbGameHB
            // 
            this.cmbGameHB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGameHB.FormattingEnabled = true;
            this.cmbGameHB.Location = new System.Drawing.Point(89, 72);
            this.cmbGameHB.Name = "cmbGameHB";
            this.cmbGameHB.Size = new System.Drawing.Size(194, 23);
            this.cmbGameHB.TabIndex = 3;
            this.cmbGameHB.SelectedIndexChanged += new System.EventHandler(this.cmbGameHB_SelectedIndexChanged);
            // 
            // listViewHB
            // 
            this.listViewHB.CheckBoxes = true;
            this.listViewHB.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3});
            this.listViewHB.GridLines = true;
            this.listViewHB.HideSelection = false;
            listViewItem2.StateImageIndex = 0;
            this.listViewHB.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem2});
            this.listViewHB.LabelWrap = false;
            this.listViewHB.Location = new System.Drawing.Point(17, 197);
            this.listViewHB.Name = "listViewHB";
            this.listViewHB.Size = new System.Drawing.Size(269, 253);
            this.listViewHB.TabIndex = 6;
            this.listViewHB.UseCompatibleStateImageBehavior = false;
            this.listViewHB.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Payment Receipts";
            this.columnHeader3.Width = 250;
            // 
            // btnLoadGameFileHB
            // 
            this.btnLoadGameFileHB.Location = new System.Drawing.Point(17, 168);
            this.btnLoadGameFileHB.Name = "btnLoadGameFileHB";
            this.btnLoadGameFileHB.Size = new System.Drawing.Size(269, 23);
            this.btnLoadGameFileHB.TabIndex = 5;
            this.btnLoadGameFileHB.Text = "Browse to load game file";
            this.btnLoadGameFileHB.UseVisualStyleBackColor = true;
            this.btnLoadGameFileHB.Click += new System.EventHandler(this.btnLoadGameFileHB_Click);
            // 
            // btnDeleteSelectedReceiptsHB
            // 
            this.btnDeleteSelectedReceiptsHB.Location = new System.Drawing.Point(17, 456);
            this.btnDeleteSelectedReceiptsHB.Name = "btnDeleteSelectedReceiptsHB";
            this.btnDeleteSelectedReceiptsHB.Size = new System.Drawing.Size(269, 23);
            this.btnDeleteSelectedReceiptsHB.TabIndex = 5;
            this.btnDeleteSelectedReceiptsHB.Text = "Delete selected payment receipts";
            this.btnDeleteSelectedReceiptsHB.UseVisualStyleBackColor = true;
            this.btnDeleteSelectedReceiptsHB.Click += new System.EventHandler(this.btnDeleteSelectedReceiptsHB_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 133);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 15);
            this.label8.TabIndex = 1;
            this.label8.Text = "Bet Amount:";
            // 
            // txtBetAmountHB
            // 
            this.txtBetAmountHB.Location = new System.Drawing.Point(89, 130);
            this.txtBetAmountHB.Name = "txtBetAmountHB";
            this.txtBetAmountHB.Size = new System.Drawing.Size(194, 23);
            this.txtBetAmountHB.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 15);
            this.label7.TabIndex = 1;
            this.label7.Text = "Username:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 15);
            this.label6.TabIndex = 1;
            this.label6.Text = "Password:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 15);
            this.label5.TabIndex = 1;
            this.label5.Text = "Game:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 15);
            this.label4.TabIndex = 1;
            this.label4.Text = "Column:";
            // 
            // txtUsernameHB
            // 
            this.txtUsernameHB.Location = new System.Drawing.Point(89, 13);
            this.txtUsernameHB.Name = "txtUsernameHB";
            this.txtUsernameHB.Size = new System.Drawing.Size(194, 23);
            this.txtUsernameHB.TabIndex = 2;
            // 
            // txtPasswordHB
            // 
            this.txtPasswordHB.Location = new System.Drawing.Point(89, 41);
            this.txtPasswordHB.Name = "txtPasswordHB";
            this.txtPasswordHB.Size = new System.Drawing.Size(194, 23);
            this.txtPasswordHB.TabIndex = 2;
            this.txtPasswordHB.UseSystemPasswordChar = true;
            // 
            // cmbColumnHB
            // 
            this.cmbColumnHB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbColumnHB.FormattingEnabled = true;
            this.cmbColumnHB.Location = new System.Drawing.Point(89, 101);
            this.cmbColumnHB.Name = "cmbColumnHB";
            this.cmbColumnHB.Size = new System.Drawing.Size(194, 23);
            this.cmbColumnHB.TabIndex = 3;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnStartWager);
            this.tabPage3.Controls.Add(this.cmbGameWebsiteWager);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(302, 513);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Wager";
            // 
            // btnStartWager
            // 
            this.btnStartWager.Location = new System.Drawing.Point(19, 76);
            this.btnStartWager.Name = "btnStartWager";
            this.btnStartWager.Size = new System.Drawing.Size(259, 23);
            this.btnStartWager.TabIndex = 2;
            this.btnStartWager.Text = "Start";
            this.btnStartWager.UseVisualStyleBackColor = true;
            this.btnStartWager.Click += new System.EventHandler(this.btnStartWager_Click);
            // 
            // cmbGameWebsiteWager
            // 
            this.cmbGameWebsiteWager.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGameWebsiteWager.FormattingEnabled = true;
            this.cmbGameWebsiteWager.Location = new System.Drawing.Point(19, 33);
            this.cmbGameWebsiteWager.Name = "cmbGameWebsiteWager";
            this.cmbGameWebsiteWager.Size = new System.Drawing.Size(259, 23);
            this.cmbGameWebsiteWager.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(157, 15);
            this.label9.TabIndex = 0;
            this.label9.Text = "Select game website to start:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.listView3);
            this.tabPage4.Controls.Add(this.comboBox5);
            this.tabPage4.Controls.Add(this.comboBox4);
            this.tabPage4.Controls.Add(this.textBox6);
            this.tabPage4.Controls.Add(this.textBox5);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Controls.Add(this.label11);
            this.tabPage4.Controls.Add(this.textBox4);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.button4);
            this.tabPage4.Controls.Add(this.btnRemoveTickets);
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(302, 513);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Supabet Games";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // listView3
            // 
            this.listView3.CheckBoxes = true;
            this.listView3.GridLines = true;
            this.listView3.HideSelection = false;
            listViewItem3.StateImageIndex = 0;
            this.listView3.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem3});
            this.listView3.LabelWrap = false;
            this.listView3.Location = new System.Drawing.Point(18, 194);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(269, 253);
            this.listView3.TabIndex = 6;
            this.listView3.UseCompatibleStateImageBehavior = false;
            this.listView3.View = System.Windows.Forms.View.Details;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(90, 98);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(194, 23);
            this.comboBox5.TabIndex = 3;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(90, 69);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(194, 23);
            this.comboBox4.TabIndex = 3;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(90, 38);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(194, 23);
            this.textBox6.TabIndex = 2;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(90, 10);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(194, 23);
            this.textBox5.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 101);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 15);
            this.label14.TabIndex = 1;
            this.label14.Text = "Column:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 72);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 15);
            this.label13.TabIndex = 1;
            this.label13.Text = "Game:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 41);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 15);
            this.label12.TabIndex = 1;
            this.label12.Text = "Password:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 13);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 15);
            this.label11.TabIndex = 1;
            this.label11.Text = "Username:";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(90, 127);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(194, 23);
            this.textBox4.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 130);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 15);
            this.label10.TabIndex = 1;
            this.label10.Text = "Bet Amount:";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(18, 453);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(269, 23);
            this.button4.TabIndex = 5;
            this.button4.Text = "Delete selected payment receipts";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // btnRemoveTickets
            // 
            this.btnRemoveTickets.Location = new System.Drawing.Point(18, 165);
            this.btnRemoveTickets.Name = "btnRemoveTickets";
            this.btnRemoveTickets.Size = new System.Drawing.Size(269, 23);
            this.btnRemoveTickets.TabIndex = 5;
            this.btnRemoveTickets.Text = "Remove all my current saved Tickets";
            this.btnRemoveTickets.UseVisualStyleBackColor = true;
            this.btnRemoveTickets.Click += new System.EventHandler(this.btnRemoveTicketsSapa_Click);
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Payment Receipts";
            this.columnHeader2.Width = 250;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Payment Receipts";
            this.columnHeader4.Width = 250;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 519);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(310, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // mainform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(310, 541);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tabControl1);
            this.Name = "mainform";
            this.Text = "Game Bot";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.mainform_FormClosing);
            this.Load += new System.EventHandler(this.mainform_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mainform_KeyPress);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ListView listViewNL;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Button btnRemoveSavedTicketsNL;
        private System.Windows.Forms.Button btnLoadGameFileNL;
        private System.Windows.Forms.CheckBox chkPayWalletNL;
        private System.Windows.Forms.ComboBox cmbColumnNL;
        private System.Windows.Forms.ComboBox cmbGameNL;
        private System.Windows.Forms.TextBox txtPinNL;
        private System.Windows.Forms.TextBox txtMobileNoNL;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblMobileNo;
        private System.Windows.Forms.Button btnDeletedSelectedReceiptsNL;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtBetAmountHB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtUsernameHB;
        private System.Windows.Forms.TextBox txtPasswordHB;
        private System.Windows.Forms.ComboBox cmbColumnHB;
        private System.Windows.Forms.ListView listViewHB;
        private System.Windows.Forms.Button btnLoadGameFileHB;
        private System.Windows.Forms.Button btnDeleteSelectedReceiptsHB;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ComboBox cmbGameWebsiteWager;
        private System.Windows.Forms.Button btnStartWager;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnRemoveTickets;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.CheckBox chkPowerBallPlus;
        private System.Windows.Forms.CheckBox chkLottoPlus2;
        private System.Windows.Forms.CheckBox chkLottoPlus1;
        private System.Windows.Forms.ComboBox cmbGameHB;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}

