﻿using Microsoft.Win32;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.Extensions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection.Metadata.Ecma335;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace GameBot.Modules
{
    public class MyNLGames
    {
        public static mainform main_form;

        public IWebDriver webDriver;
        ChromeDriverService service = ChromeDriverService.CreateDefaultService();

        public string myMobileNo;
        public string myPassword;
        public string myWebsiteUrl;
        public string gameName;
        public string gameFile;
        public string chosenNumbers;

        private ReadOnlyCollection<IWebElement> tags1;
        internal string gameUrl;
        internal int colNum;
        internal bool isLottoPlus1;
        internal bool isPowerPlus;
        internal bool isLottoPlus2;
        internal bool isPayFromWallet;
        public MyNLGames(mainform frm)
        {            
            main_form = frm;
        }

        [Obsolete]
        public void runGameProcess()
        {
            bool isNumberSelected = false;
            string[] lines = System.IO.File.ReadAllLines(gameFile);
            RegistryKey key = Registry.CurrentUser.CreateSubKey(@"SOFTWARE\GameBotSettings");

            int cnt_round = Convert.ToInt32( key.GetValue("Setting_Record_Count_" + gameName, 0));
            int j = 20 * cnt_round;
            

            main_form.setStatus("Opening " + myWebsiteUrl + " Game Page...");

            

            //int max_loop = Math.Min(lines.Length, 700);
            int max_loop = lines.Length;
            
            webDriver = new ChromeDriver(service);
            webDriver.Manage().Window.Maximize();

            
            if (!loggedIn())
            {
                Login(myMobileNo, myPassword);
            }
            Restart:

            webDriver.Url = gameUrl;

        //webDriver.Manage().Window.Position = new System.Drawing.Point(400, 10);
        //webDriver.Manage().Window.Size = new System.Drawing.Size(1024, 768);

            main_form.setStatus("Starting choose number process...");

            isNumberSelected = false;
            var elements = webDriver.FindElements(By.XPath("//div[contains(@class,'buttonValue')][contains(text(),'" + chosenNumbers + "')]"));
            foreach(IWebElement element in elements)
            {

                //var p_element = element.FindElement(By.XPath(".."));
                //p_element.Click();
                Thread.Sleep(200);
                IWebElement eleWrap = element.FindElement(By.XPath("..")).FindElement(By.XPath(".."));
                
                while( ! element.Enabled)
                {

                }

                while (eleWrap.GetAttribute("class").Contains("empty"))
                    element.Click();
                //check if clicked correctly


                //var cancelElement = webDriver.FindElement(By.XPath("//span[contains(@class,'closePanel')][contains(text(), 'Cancel')]"));
                //cancelElement.Click();
                Thread.Sleep(200);
                string line = lines[j];
                if (chosenNumbers.Contains("+"))
                {
                    var leftContainer = webDriver.FindElement(By.XPath("//div[@class='leftPart']"));
                    var rightContainer = webDriver.FindElement(By.XPath("//div[@class='rightPart']"));                                                    

                    if (line.Trim() != "")
                    {
                        string[] balls = line.Split(" ");

                        if (balls.Length == colNum)
                        {
                            for (int k = 0; k < colNum - 1; k++)
                            {
                                IWebElement ballElement = leftContainer.FindElement(By.XPath(".//span[contains(text(), '" + balls[k] + "')]")).FindElement(By.XPath(".."));
                                IWebElement ballEleWrap = ballElement.FindElement(By.XPath(".."));


                                while (!ballEleWrap.GetAttribute("class").Contains("active"))
                                    ballElement.Click();
                            }
                            try
                            {
                                var plusBallElement = rightContainer.FindElement(By.XPath(".//li//span[text()='" + balls[colNum - 1] + "']")).FindElement(By.XPath(".."));
                                plusBallElement.Click();
                            }
                            catch(Exception xe)
                            {
                                closePopup("error_popup");

                                Thread.Sleep(500);
                                var plusBallElement = rightContainer.FindElement(By.XPath(".//li//span[text()='" + balls[colNum - 1] + "']")).FindElement(By.XPath(".."));
                                plusBallElement.Click();
                            }

                        }
                        else
                            continue;

                        removeChatBox();
                        Thread.Sleep(200);
                        var btnElement = webDriver.FindElement(By.XPath("//div[@class='buttonValue'][contains(text(), 'Select')]"));

                        btnElement.Click();
                        j++;

                        isNumberSelected = true;
                        if (j >= max_loop)
                        {
                            break;
                        }
                    }
                }
                else
                {
                    if (line.Trim() != "")
                    {
                        string[] balls = line.Trim().Split(" ");
                        if (balls.Length == colNum)
                        {
                            for (int k = 0; k < colNum ; k++)
                            {
                                IWebElement ballElement = webDriver.FindElement(By.ClassName("gameArea")).FindElement(By.XPath(".//span[contains(text(), '" + balls[k] + "')]")).FindElement(By.XPath(".."));
                                IWebElement ballEleWrap = ballElement.FindElement(By.XPath(".."));

                                while (!ballEleWrap.GetAttribute("class").Contains("active"))
                                    ballElement.Click();
                            }

                            removeChatBox();
                            Thread.Sleep(200);
                            var btnElement = webDriver.FindElement(By.XPath("//div[@class='buttonValue'][contains(text(), 'Select')]"));

                            btnElement.Click();
                            j++;

                            isNumberSelected = true;
                        }
                        else
                        {
                            MessageBox.Show("Incorrect input!");
                            killProcess();
                        }
                    }
                }
            }

                // click checkbox
            if (isNumberSelected)
            {
                if (isLottoPlus1)
                {
                    try {
                        var chkElement = webDriver.FindElement(By.XPath("//label[contains(@class, 'chb-label')][contains(text(), 'Play Lotto Plus1')]"));
                        chkElement.Click();
                    }catch(Exception xe){ }
                }
                if (isLottoPlus2)
                {
                    try
                    {
                        var chkElement = webDriver.FindElement(By.XPath("//label[contains(@class, 'chb-label')][contains(text(), 'Play Lotto Plus2')]"));
                        chkElement.Click();
                    }catch (Exception xe) { }
                }
                if (isPowerPlus)
                {
                    CheckAgain:
                    try
                    {
                        //Actions action = new Actions(webDriver);
                        var detailWrap = webDriver.FindElement(By.ClassName("detailWrap"));
                        var chkElement = detailWrap.FindElement(By.ClassName("chb-label"));
                        var chkInput = webDriver.FindElement(By.Id("chb-powerballPlus"));
                        //action.MoveToElement(chkElement).Build().Perform();
                        while(!chkInput.Selected)
                        {
                            chkElement.Click();
                        }
                    }
                    catch(Exception xe)
                    {
                        goto CheckAgain;
                    }
                }
            }
            //Thread.Sleep(200);
            main_form.setStatus("Adding ticket records to Cart...");
            webDriver.ExecuteJavaScript("return document.getElementById('my-chat-element').remove();");

            var btnAddToCart = webDriver.FindElement(By.XPath("//button[contains(@class,'addToCart')]"));
            btnAddToCart.Click();
            cnt_round++;
            if(isPayFromWallet || j >= max_loop || cnt_round >= 35)
            {
                Thread.Sleep(2000);
                main_form.setStatus("Opening cart...");
                webDriver.Url = myWebsiteUrl + @"/cart";
                    
                    
                main_form.setStatus("Checking for available cash balance...");
                var totalEle = webDriver.FindElement(By.XPath("//div[contains(@class, 'totalAmount')]"));
                double myTotalAmount = Convert.ToDouble(totalEle.Text.Replace("R", "").Replace(",", "").Replace(" ", ""), CultureInfo.InvariantCulture);

                var cashEle = webDriver.FindElement(By.XPath("//span[contains(@class, 'cash-balance')]"));
                double myCashBalance = Convert.ToDouble(cashEle.Text.Replace("R", "").Replace(",", "").Replace(" ", ""), CultureInfo.InvariantCulture);


                if (myCashBalance >= myTotalAmount)
                {
                    main_form.setStatus("Paying payment from your wallet...");
                    var btnPayFromWallet = webDriver.FindElement(By.XPath("//div[contains(@class, 'buttonValue')][contains(text(), 'Pay From My Wallet')]"));
                    btnPayFromWallet.Click();

                    main_form.setStatus("Confirming payment...");
                    var btnConfirmPay = webDriver.FindElement(By.XPath("//div[contains(@class, 'buttonValue')][contains(text(), 'Confirm and Pay Now')]"));
                    btnConfirmPay.Click();
                    if (j >= max_loop)
                    {
                        MessageBox.Show("End of the input file!");
                        killProcess();
                        return;
                    }
                    else
                    {
                        goto Restart;
                    }
                }
                else
                {
                    main_form.setStatus("The cash balance is insufficient!");

                    killProcess();
                    return;
                }                    
            }
            else
            {

                if (j < max_loop - 1)
                {
                        //var btnPlaymore = webDriver
                        goto Restart;
                }
            }
        }

        private void removeChatBox()
        {
            var chatbox = webDriver.FindElement(By.Id("my-chat-element")).FindElement(By.XPath("//button[contains(@class, 'ChatContainer-button')]"));

            IJavaScriptExecutor js = (IJavaScriptExecutor)webDriver;
            js.ExecuteScript("arguments[0].setAttribute('style', 'visibility: hidden')", chatbox);
        }

        private void killProcess()
        {
            //main_form.setStatus("Process Stopped");
            main_form.setWagerButtonText(true);
            webDriver.Quit();
        }

        private bool loggedIn()
        {
            // Navigate to url
            webDriver.Url = myWebsiteUrl;
            try
            {
                webDriver.FindElement(By.XPath("//a[contains(@class,'logoutBtn')][contains(text(),'LOGOUT')]"));
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public void closeDriver()
        {
            if(webDriver != null)
                webDriver.Quit();
        }

        [Obsolete]
        internal void removeAllTickets()
        {
            if(webDriver == null)
            {
                webDriver = new ChromeDriver(service);
                webDriver.Manage().Window.Maximize();
            }
            if(myMobileNo != "" && myPassword != "")
            {
                main_form.setStatus("Loading website...");
                if(! loggedIn())
                    Login(myMobileNo, myPassword);
                main_form.setStatus("Opening cart page to remove tickets...");

                if(myWebsiteUrl != "")
                {
                    webDriver.Navigate().GoToUrl(myWebsiteUrl + @"/cart");

                    Thread.Sleep(2000);


                    //hide header
                    var headerEle = webDriver.FindElement(By.Id("sp-header"));
                    IJavaScriptExecutor js = (IJavaScriptExecutor)webDriver;
                    js.ExecuteScript("arguments[0].setAttribute('style', 'visibility: hidden')", headerEle);


                    //webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(8000);
                    var cartWrap = webDriver.FindElement(By.ClassName("myCartWrap"));

                    tags1 = cartWrap.FindElements(By.XPath("//span[contains(text(), 'Remove my Ticket')]"));
                    if(tags1.Count > 0)
                    {
                        foreach (IWebElement tag in tags1)
                        {
                            //WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(10));

                            //wait.Until(ExpectedConditions.ElementToBeClickable(tag));//WebDriverTimeoutException occurs here sometimes...

                            //tag.Click();
                            //var eleForm = tag.FindElement(By.XPath("..")).FindElement(By.XPath(".."));
                            Thread.Sleep(2000);
                            try
                            {
                                tag.Click();
                            }
                            catch (Exception xe)
                            {
                                MessageBox.Show(xe.Message);
                            }


                            Thread.Sleep(2000);
                            try
                            {
                                closePopup("error_popup");
                            }
                            catch (Exception xe)
                            {
                                MessageBox.Show(xe.Message);
                            }
                            
                        }
                    }
                    else
                    {
                        MessageBox.Show("No tickets to remove!");
                        RegistryKey key = Registry.CurrentUser.CreateSubKey(@"SOFTWARE\GameBotSettings");
                        key.SetValue("Setting_Record_Count_" + gameName, 0);
                    }
                }
            }
            main_form.setStatus("Ready");
        }

        private void closePopup(string myID)
        {
            main_form.setStatus("Checking for a popup...");

            var modalElement = webDriver.FindElement(By.Id(myID));
            if(modalElement != null)
            {
                var closeBtn = modalElement.FindElement(By.TagName("a"));
                if(closeBtn != null)
                {
                    if (closeBtn.Displayed)
                        closeBtn.Click();
                }
            }
        }

        [Obsolete]
        public void Login(string username, string password)
        {
            if(webDriver == null)
            {
                webDriver = new ChromeDriver(service);
                webDriver.Manage().Window.Maximize();
            }

            try
            {
                var element = webDriver.FindElement(By.XPath("//span[@class='closeBTN']"));
                element.Click();
            }
            catch (Exception xe)
            {

            }

            // Find the username field (Facebook calls it "email") and enter value
            var mobile = webDriver.FindElement(By.Id("userName_email"));
            mobile.SendKeys(username);

            // Find the password field and enter value
            var pn = webDriver.FindElement(By.Id("password"));
            pn.SendKeys(password);
            var wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(200));

            pn.Submit();

            wait.Until(ExpectedConditions.StalenessOf(mobile));

        }
    }
}
