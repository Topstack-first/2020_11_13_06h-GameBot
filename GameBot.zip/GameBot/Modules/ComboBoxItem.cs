﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameBot.Modules
{
    public class ComboBoxItem
    {
        public ComboBoxItem()
        {

        }

        public ComboBoxItem(string text, int value)
        {
            Text = text;
            Value = value;
        }
        public string Text { get; set; }
        public object Value { get; set; }

        public override string ToString()
        {
            return Text;
        }
    }
}
