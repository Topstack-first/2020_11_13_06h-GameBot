﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace GameBot.Modules
{
    public class MyHBGames
    {
        public static mainform main_form;

        public IWebDriver webDriver;
        ChromeDriverService service = ChromeDriverService.CreateDefaultService();

        public string userName;
        public string password;
        public string websiteUrl;
        public string gameName;
        internal string gameFile;
        internal double betAmount;
        internal string myWebsiteUrl;
        internal int tournamentId;
        internal string columnName;
        internal int countBall;

        public MyHBGames(mainform frm)
        {
            main_form = frm;
        }
        public void runGameProcess()
        {
            string[] lines = System.IO.File.ReadAllLines(gameFile);

            if(lines.Length > 0)
            {
                webDriver = new ChromeDriver(service);
                webDriver.Manage().Window.Maximize();

                try
                {
                    if (!loggedIn())
                    {
                        Login(userName, password);
                    }

                    Thread.Sleep(1000);
                    chooseLuckyNumbers();

                    Thread.Sleep(3000);
                    chooseCountry();

                    Thread.Sleep(2000);
                    chooseGame();

                    Thread.Sleep(5000);

                    webDriver.SwitchTo().Frame("ifBetEvents");
                    var eleLabel = webDriver.FindElement(By.XPath("//td[contains(text(),'" + columnName + "')]"));
                    var row = eleLabel.FindElement(By.XPath(".."));
                    var btnBet = row.FindElement(By.CssSelector("img"));
                    btnBet.Click();

                    Thread.Sleep(3000);

                    int cntBet = 0;

                    string number_tbl_id = "";
                    if (tournamentId == 3032656 || gameName == "SA Powa Numbas")//USA
                    {
                        number_tbl_id = "BetEvents1_ctl04_tblMainSetSpecial";
                    }
                    else//SA
                    {
                        number_tbl_id = "BetEvents1_ctl04_tblNumbers";
                    }
                    var eleNumberTable = webDriver.FindElement(By.Id(number_tbl_id));

                    if ( ! columnName.Contains("&") || gameName == "SA Lotto Draw" || gameName == "SA Daily Lotto")//with only MainBall
                    {

                        for (int i = 0; i < lines.Length; i++)
                        {
                            string[] rows = lines[i].Split(" ");
                            if (rows.Length != countBall)
                            {
                                MessageBox.Show("Input file is not correct!");
                                return;
                            }

                            for (int j = 0; j < countBall; j++)
                            {
                                var eleNums = eleNumberTable.FindElements(By.CssSelector("td"));
                                for (int k = 0; k < eleNums.Count; k++)
                                {
                                    //MessageBox.Show(rows[j] + "->" + eleNums[k].Text);
                                    if (Convert.ToInt32(rows[j]) == Convert.ToInt32(eleNums[k].Text))
                                    {
                                        eleNums[k].Click();
                                        break;
                                    }
                                }
                                
                            }

                            //BetEvents1_ctl04_btnBetLottoSelected
                            //BetEvents1_ctl04_btnBetSpecial: SA Powa numbas
                            string strSubBetBtn = "BetEvents1_ctl04_btnBetSpecial";
                            if(gameName == "SA Lotto Draw" || gameName == "SA Daily Lotto")
                            {
                                strSubBetBtn = "BetEvents1_ctl04_btnBetLottoSelected";
                            }
                            var btnSubBet = webDriver.FindElement(By.Id(strSubBetBtn));
                            btnSubBet.Click();

                            Thread.Sleep(500);
                            //set bet amount
                            webDriver.SwitchTo().DefaultContent();
                            webDriver.SwitchTo().Frame("ifYourBets");

                            var eleBetBackgrounds = webDriver
                                .FindElement(By.Id("ctl30_divPrint"))
                                .FindElements(By.CssSelector("div[class='yourBetBackground']"));

                            var eleBetAmount = eleBetBackgrounds[eleBetBackgrounds.Count - 1]
                                .FindElement(By.CssSelector("input"));
                            eleBetAmount.Clear();
                            eleBetAmount.SendKeys(betAmount.ToString());

                            cntBet++;
                            if (cntBet >= 10)
                            {
                                cntBet = 0;
                                var btnSubmit = webDriver.FindElement(By.Id("ctl30_btnSubmit"));
                                btnSubmit.Click();
                                Thread.Sleep(500);
                            }

                            webDriver.SwitchTo().DefaultContent();
                            webDriver.SwitchTo().Frame("ifBetEvents");

                            //clear numbers
                            for (int j = 0; j < countBall; j++)
                            {
                                var eleNums = eleNumberTable.FindElements(By.CssSelector("td"));
                                for (int k = 0; k < eleNums.Count; k++)
                                {
                                    if (Convert.ToInt32(rows[j]) == Convert.ToInt32(eleNums[k].Text))
                                    {
                                        eleNums[k].Click();
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else//with Bonus
                    {
                        var eleBonusTable = webDriver.FindElement(By.Id("BetEvents1_ctl04_tblBonusSetSpecial"));
                        for (int i = 0; i < lines.Length; i++)
                        {
                            string[] rows = lines[i].Split(" ");
                            if (rows.Length != countBall)
                            {
                                MessageBox.Show("Input file is not correct!");
                                return;
                            }

                            //choose mainset ball
                            for (int j = 0; j < countBall - 1; j++)
                            {
                                var eleNums = eleNumberTable.FindElements(By.CssSelector("td"));
                                for (int k = 0; k < eleNums.Count; k++)
                                {
                                    //MessageBox.Show(rows[j] + "->" + eleNums[k].Text);
                                    if (Convert.ToInt32(rows[j]) == Convert.ToInt32(eleNums[k].Text))
                                    {
                                        eleNums[k].Click();
                                        break;
                                    }
                                }
                            }

                            //choose bonus ball
                            var eleBonuses = eleBonusTable.FindElements(By.CssSelector("td"));
                            for (int k = 0; k < eleBonuses.Count; k++)
                            {
                                if (Convert.ToInt32(rows[countBall - 1]) == Convert.ToInt32(eleBonuses[k].Text))
                                {
                                    eleBonuses[k].Click();
                                    break;
                                }
                            }

                            var btnSubBet = webDriver.FindElement(By.Id("BetEvents1_ctl04_btnBetSpecial"));
                            btnSubBet.Click();

                            Thread.Sleep(500);
                            //set bet amount
                            webDriver.SwitchTo().DefaultContent();
                            webDriver.SwitchTo().Frame("ifYourBets");

                            var eleBetBackgrounds = webDriver
                                .FindElement(By.Id("ctl30_divPrint"))
                                .FindElements(By.CssSelector("div[class='yourBetBackground']"));

                            var eleBetAmount = eleBetBackgrounds[eleBetBackgrounds.Count - 1]
                                .FindElement(By.CssSelector("input"));
                            eleBetAmount.Clear();
                            eleBetAmount.SendKeys(betAmount.ToString());

                            cntBet++;
                            if (cntBet >= 10)
                            {
                                cntBet = 0;
                                var btnSubmit = webDriver.FindElement(By.Id("ctl30_btnSubmit"));
                                btnSubmit.Click();
                                Thread.Sleep(500);
                            }

                            webDriver.SwitchTo().DefaultContent();
                            webDriver.SwitchTo().Frame("ifBetEvents");

                            //clear numbers
                            for (int j = 0; j < countBall - 1; j++)
                            {
                                var eleNums = eleNumberTable.FindElements(By.CssSelector("td"));
                                for (int k = 0; k < eleNums.Count; k++)
                                {
                                    if (Convert.ToInt32(rows[j]) == Convert.ToInt32(eleNums[k].Text))
                                    {
                                        eleNums[k].Click();
                                        break;
                                    }
                                }
                            }
                            //clear bonus ball
                            for (int k = 0; k < eleBonuses.Count; k++)
                            {
                                if (Convert.ToInt32(rows[countBall - 1]) == Convert.ToInt32(eleBonuses[k].Text))
                                {
                                    eleBonuses[k].Click();
                                    break;
                                }
                            }
                        }                        
                    }
                }
                catch(Exception xe)
                {
                    MessageBox.Show(xe.Message);
                }
            }
        }

        private void chooseGame()
        {
            //var ele = webDriver.FindElement(By.XPath("//table[@class='eventBrowserTournamentHeadingSubTable'][contains(text(), '" + gameName + "')]"));
            var ele = webDriver.FindElement(By.CssSelector("div[tournamentid='" + tournamentId + "'][elemtype='2']"));
            ele.Click();

            Thread.Sleep(1000);

            var ele2 = webDriver.FindElement(By.CssSelector("div[tournamentid='" + tournamentId + "'][elemtype='3']"));
            ele2.Click();
        }

        private void chooseCountry()
        {
            if (tournamentId == 3032656)//USA
            {
                //var ele = webDriver.FindElement(By.XPath("//table[@class='eventBrowserTournamentHeadingSubTable'][contains(text(), 'SOUTH AFRICA')]"));
                var ele = webDriver.FindElement(By.CssSelector("div[class='tournamentTab'][countryid='184']"));
                ele.Click();
            }
            else//SA
            {
                //var ele = webDriver.FindElement(By.XPath("//table[@class='eventBrowserTournamentHeadingSubTable'][contains(text(), 'UNITED STATES')]"));
                var ele = webDriver.FindElement(By.CssSelector("div[class='tournamentTab'][countryid='2']"));
                ele.Click();
            }
        }

        private void chooseLuckyNumbers()
        {
            webDriver.SwitchTo().DefaultContent();

            var ele = webDriver.FindElement(By.CssSelector("div[class='sportTab'][sportname='LUCKY NUMBERS']"));
            ele.Click();
        }

        private void Login(string myName, string myPassword)
        {
            if (webDriver == null)
            {
                webDriver = new ChromeDriver(service);
                webDriver.Manage().Window.Maximize();
            }
            // Navigate to url
            //webDriver.Url = myWebsiteUrl;


            webDriver.SwitchTo().Frame("ifLogin");

            var wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(120));

            wait.Until(ExpectedConditions.ElementExists(By.Id("ctl30_Login1_txtUserName")));

            var chkAgree = webDriver.FindElement(By.Id("ctl30_Login1_chkAgreeToTerms"));
            chkAgree.Click();

            // Find the username field (Facebook calls it "email") and enter value
            var usernameEle = webDriver.FindElement(By.Id("ctl30_Login1_txtUserName"));
            usernameEle.SendKeys(myName);

            // Find the password field and enter value
            var pn = webDriver.FindElement(By.Id("ctl30_Login1_txtPassword"));
            pn.SendKeys(password);

            var btnLogin = webDriver.FindElement(By.Id("ctl30_Login1_btnLogin"));
            btnLogin.Click();
            wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(200));
            //pn.Submit();
            wait.Until(ExpectedConditions.StalenessOf(usernameEle));
        }

        private bool loggedIn()
        {
            webDriver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(120);
            webDriver.Url = myWebsiteUrl;
            try
            {
                webDriver.FindElement(By.Id("ctl00_ContentPlaceHolder1_Login1_btnLogin"));

                return false;
            }
            catch (NoSuchElementException xe)
            {
                //MessageBox.Show(xe.Message);
                return true;
            }
        }
    }
}
